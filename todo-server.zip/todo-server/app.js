var path = require("path");
var express = require("express");
var app = express();
var cors = require("cors");

/**
 * Static
 */

const PORT = process.env.PORT || 5000;
const DATA_DIR = path.join(__dirname, "data");
const BASE_DELAY = 500;
const DELAY_SPREAD = 1000;

let todos = [];

/**
 * Middleware
 */
app.use(cors());
// Emulate server response delay
app.use(function (req, res, next) {
  setTimeout(next, BASE_DELAY + Math.random() * DELAY_SPREAD);
});

app.use(express.json());
app.use(express.urlencoded());
app.use(express.static("static"));

/**
 * Routing
 */

// List of all todo lists
app.get("/todos", function (req, res) {
  return res.send(todos);
});

// Create todo list
app.post("/todos", function (req, res) {
  if (!req.body.todo) {
    res.status(500);
    res.send({
      updated: false,
      error: {
        name: "Empty param",
        message: 'Param "todo" can\'t be empty',
      },
    });
    return;
  }
  // Invalid JSON body
  try {
    parsedListData = req.body.todo;
  } catch (parseError) {
    res.status(500);
    res.send({
      updated: false,
      error: {
        name: parseError.name,
        message: parseError.message,
      },
    });
    return;
  }
  todos.push(req.body.todo);
  res.send(req.body.todo);
});

// Updat
app.put("/todos/:id", function (req, res) {
  if (!req.body.todo) {
    res.status(500);
    res.send({
      updated: false,
      error: {
        name: "Empty param",
        message: 'Param "todo" can\'t be empty',
      },
    });
    return;
  }
  // Invalid JSON body
  try {
    parsedListData = req.body.todo;
  } catch (parseError) {
    res.status(500);
    res.send({
      updated: false,
      error: {
        name: parseError.name,
        message: parseError.message,
      },
    });
    return;
  }
  todos = todos.map((todo) => {
    if (+todo.id === +req.params.id) {
      return req.body.todo;
    }

    return todo;
  });

  const todo = todos.find((item) => +item.id === +req.params.id);

  res.send(todo);
});

// Delete todo
app.delete("/todos/delete/:id", function (req, res) {
  const todo = todos.find((item) => +item.id === +req.params.id);
  todos = todos.filter((item) => +item.id !== +req.params.id);
  res.send(todo);
});

app.listen(PORT);
console.log("App started at", PORT);
